"""
MCP Starter - FastAPI Application.
"""
